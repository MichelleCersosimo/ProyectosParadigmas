
Proyecto de composici�n musical algor�tmica
Oscar Esquivel Oviedo, B22410
Diana Garbanzo Quir�s, B12685

Para probar el programa se debe seguir dos pasos:

1. Ejecutar el archivo "Compositor.pl", y usar la regla "cancionRock" enviando listas
  vac�as como par�metros 1 y 2, m�s un tercer par�metro de retorno, por ejemplo:
	cancionRock([],[],C).
  �sto generar� un archivo de texto llamado "cancion.txt".

2. Ejecutar el archivo "ComposicionAlgoritmica.jar", en la interfaz hacer click en el
  bot�n "Seleccionar archivo", en la nueva ventana escoger el archivo "cancion.txt"
  (o cualquiera de los otros archivos "cancion#.txt" que se incluyen en la carpeta
  "Canciones ejemplo"), luego hacer click en el bot�n "Escuchar canci�n". La interfaz
  no puede usarse hasta que la reproducci�n termine.